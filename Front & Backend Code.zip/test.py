import pickle
import sklearn
from sklearn.feature_extraction.text import TfidfVectorizer

loaded_model1=pickle.load(open('Disater Prediction Model','rb'))
# print(loaded_model1)
# loaded_model2=pickle.load(open('Disater Prediction Model2','rb'))
# print(loaded_model2)
loaded_model3=pickle.load(open('TFIDF_Pickle','rb'))
# print(loaded_model3)
filename= 'Disater Prediction Model'
loaded_model=pickle.load(open(filename,'rb'))
o = input("Enter the message\n")
vec= loaded_model3.transform([o])
Res=loaded_model.predict(vec)
if Res == 1:
    print("Disaster tweet")
else:
    print("Not a Disaster tweet")
