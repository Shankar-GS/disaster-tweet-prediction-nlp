import pickle
import sklearn
from sklearn.feature_extraction.text import TfidfVectorizer


def tweet(o):
    loaded_model1 = pickle.load(open('Disater Prediction Model', 'rb'))
    loaded_model3 = pickle.load(open('TFIDF_Pickle', 'rb'))
    x = input("Enter the message\n")
    # vec = loaded_model3.transform([o])
    # res = loaded_model1.predict(vec)
    vec = loaded_model3.transform([x])
    res = loaded_model1.predict(vec)
    return (res)

# if vec == 1:
#     print("Disaster tweet")
# else:
#     print("Not a Disaster tweet")